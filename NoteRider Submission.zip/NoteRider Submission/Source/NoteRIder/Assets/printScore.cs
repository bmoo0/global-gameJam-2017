﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class printScore : MonoBehaviour {
	public int score;
	// Use this for initialization
	void Start () {
		GameObject jumper = GameObject.Find ("Jump");
		Jump player = jumper.GetComponent<Jump> ();
		int score = player.points;
	}
	
	// Update is called once per frame
	void Update () {
		print (score);
	}

	void OnGUI() {
		//GUI.Box (new Rect (10, 10, 100, 20), score.ToString ());
	}
}
